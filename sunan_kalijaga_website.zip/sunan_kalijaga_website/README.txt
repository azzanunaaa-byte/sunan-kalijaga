# Website Sunan Kalijaga

## Isi
- `index.html`: website satu halaman yang sudah memuat HTML, CSS, dan JavaScript.
- Responsif untuk HP, tablet, dan desktop.
- Navigasi mobile, animasi saat scroll, kartu wayang dengan modal, dan kuis otomatis.

## Cara melihat
Buka `index.html` menggunakan browser.

## Cara memasukkan ke Google Sites
Google Sites tidak menjalankan file HTML/CSS/JavaScript lokal secara langsung sebagai satu website penuh. Hosting halaman ini terlebih dahulu, lalu sematkan URL-nya.

### Opsi GitHub Pages
1. Buat repository baru di GitHub.
2. Upload `index.html` ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/root`, lalu Save.
6. Tunggu URL GitHub Pages muncul, biasanya berbentuk `https://username.github.io/nama-repository/`.
7. Buka Google Sites → **Insert → Embed → By URL**.
8. Tempel URL GitHub Pages tersebut, lalu atur ukuran embed.

### Alternatif
Gunakan menu **Insert → Embed → Embed code** di Google Sites untuk menyisipkan potongan HTML. Untuk website penuh dengan JavaScript dan CSS, hosting eksternal + embed URL biasanya lebih stabil.

## Kustomisasi
- Ubah teks langsung di `index.html`.
- Ubah warna pada bagian `:root` di CSS.
- Ganti panel ilustrasi CSS dengan foto wayang milik sendiri jika tersedia.
- Ubah pertanyaan dan jawaban pada array `quizData` di bagian JavaScript.

Catatan materi: beberapa kisah dan penafsiran simbolis disajikan sebagai tradisi/penafsiran dakwah Jawa, bukan klaim bahwa seluruh bentuk wayang berasal dari satu tokoh atau satu masa.
